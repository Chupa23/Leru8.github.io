

    var canvas = document.getElementById('canvas')
    canvas.width = innerWidth-2;
    canvas.height = innerHeight-2;
    var ctx= canvas.getContext('2d')

    window.addEventListener('click' , jump);
    window.addEventListener('resize' , function(){
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight; init();})
    
    var game = false,
     carW = 50,
     carH = 50, 
     charImgWidht = 55,
     charImgHeight=55,
     x= 20,
     y = 200,
     dy = -20,
     oxp = innerWidth -20,
     oyp = 0,
     ow = 60,
     obsGap= 180,
     obsDist=300,
     oh ,
     animation=false,
     scr=0,
     dySpeed =0.4,
     jumpSpeed=-9;

   function init(){
     GameOver();
     rsGame();
   }

    //draw character-----------------------------------------
    function draw () {
      var cImg= new Image();
      cImg.src= charSrc;
      ctx.drawImage(cImg, x , y, charImgWidht, charImgHeight);
     //if (y+carH<canvas.height && y>0) {
      y+=dy;
      if(dy>-20&&dy<20){
      dy+=dySpeed }
     //}

     if (y>=canvas.height)
     { y=5;reverse() }
     if (y<=0){y=innerHeight-5;reverse()}
    }

     
    //draw Obstacles--------------------------------------------
    var ObsImage= new Image();
    ObsImage.src= 'obs.png'
    var ObsBImage= new Image();
    ObsBImage.src= 'obsB.png'
    function obstacle(ox,oy){
     this.ox=ox;
     this.oy=oy;
     this.oh = oh;
     this.drawObs = function(){
      ctx.beginPath();
      ctx.globalCompositeOperation='destination-over';
      ctx.fillStyle='black'
      ctx.drawImage(ObsImage,this.ox, this.oy, ow , this.oh);
      ctx.drawImage(ObsBImage,this.ox,this.oy+this.oh + obsGap, ow, innerHeight )
      ctx.closePath();
     }
    
     this.update = function(){
       this.ox-=2;
       if (this.ox+ow<=x&&this.ox+ow>=x-1){
         scr++  ;
         if (scr==15){
           document.getElementById('changeCharToL').className='charBt';
          // alert('Ai castigat ceva!');
          // animation=false;
          // jump();
         }}
       if(((x>=this.ox&&x<this.ox + ow) || (x+carW>=this.ox&&x+carH<this.ox+ow) ) && 
       (y<=this.oh || y+carH>=this.oh+obsGap))
        {GameOver()}

       if (this.ox== innerWidth-obsDist){
          pushNewObs();
       }
       this.drawObs();
     }
    }

    //GameOver------------------------------------------------
    var lostTextArray = [
      "Ai pierdut?",
      "Esti praf!",
      "Atat poti?",
      "Pur si simplu trist.."
    ]
     function GameOver(){
      this.lostText=lostTextArray[Math.floor(Math.random() * lostTextArray.length)];
      ctx.beginPath();
      ctx.globalCompositeOperation='source-over';
      ctx.fillStyle='grey';
      ctx.strokeStyle='black';
      ctx.font = '40px Georgia';
      ctx.strokeText(this.lostText , 10,200)
      ctx.fillText(this.lostText , 10,200)
      ctx.closePath();
       animation=false;
       game=false;
       }


    //Score--------------------------------------------------
    function score(){
      ctx.globalCompositeOperation='source-over';
      this.scre = scr.toString();
      ctx.fillStyle='black';
      ctx.strokeStyle='white';
      ctx.font= '100px Arial';
      ctx.strokeText (this.scre, innerWidth/2-50, 80)
     // ctx.fillText (this.scre, 40, 80)
    }

    // Create Obstacles--------------------------------------
    var obsArray = [];
    
    function pushObs(){
      obsArray=[];
      pushNewObs();
      }

      function pushNewObs(){
        oxp = innerWidth;
        oyp = 0;
     
        var ox= oxp;
        var oy= oyp;
        oh= Math.random()*200+100;
         obsArray.push(new obstacle(ox,oy))
         
        oxp+=obsDist;
        }
    

    //Start Game------------------------------------------------
   
    function jump(){
      if (game){
        if (!animation){animation=true;animate(); }
        if (animation) {dy=jumpSpeed } } }
    
    function rsGame(){ setTimeout(ResetGame, 100); }

    function ResetGame(){
      if (!game){
      if (!animation) {
        x=20; y=200+1;dy=-20;scr=0;
        animation=true;
        animate()
        pushObs();
        animation=false;
        game=true;}
    }}

    //Animation loop------------------------------------------------
    function animate(){
      if (animation){
      requestAnimationFrame(animate);}
      ctx.clearRect(0,0, innerWidth, innerHeight);
      draw();
      for (var i = 0; i<obsArray.length;i++){
        if (obsArray[i].ox>-ow){
         obsArray[i].update();}
        
         score();
      }
      setBgImg();
      hideButtons();
      console.log(background)
      console.log(reversed)
    }
    
  