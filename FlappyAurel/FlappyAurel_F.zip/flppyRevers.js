var background="background.png";
var reversed=true;

function reverse(){
    dySpeed=-dySpeed;jumpSpeed=-jumpSpeed; reversed=!reversed; 
    if (y>=canvas.height-5&&reversed==true||y<=5&&reversed==false)
    {jump() }
    (charSrc=='Aurel.png'&&!reversed)?charSrc='aurelv2.png': (charSrc=='aurelv2.png'&&reversed)?charSrc= 'Aurel.png':
    (charSrc=='Leru.png'&&!reversed)?charSrc='Leru2.png':(charSrc=='Leru2.png'&&reversed)?charSrc='Leru.png':scharSrc;
}


function setBgImg(){
    ctx.globalCompositeOperation='destination-over'
    if (!reversed){
        background="background2.png"
    }
    if (reversed){
        background="background.png"}
    var bgImg= new Image();
    bgImg.src=background;

    ctx.drawImage(bgImg, 0,0 ,innerWidth, innerHeight)
}


