var charSrc='Aurel.png';
var butonStart = document.getElementById('menuButtons');

function hideButtons(){
      if (game){butonStart.style.opacity='0'}
     if (!game){ butonStart.style.opacity='1'}}

function changeChar (char){
if (!game) {
 switch (char) {
     case 1: charSrc= 'Aurel.png'; carH = 50;break;
     case 2: charSrc= 'Leru.png' ;carH = 50;  break;
    // case 3: charSrc= 'Lavinia.png'; carH = 80;break;
     default: charSrc= 'Aurel.png';break;
 }
} }


